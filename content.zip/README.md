# My attempt at a basic interactive website powered by lambda. 

Goals:
 - Primary mission:
   1. create a javascript website using nodejs
 - Secondary missions:
    1. Wire up the ability to upload a file to s3
    2. connect file to a kinesis stream that will parse the file and dump into a nosql db
    3. fancy the website up in some graphical and reactive way
